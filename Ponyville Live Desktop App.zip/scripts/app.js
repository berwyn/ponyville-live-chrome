"use strict";
angular.module('PVL', ['ngAnimate']).constant('io', io).constant('jQuery', $).constant('moment', moment).constant('_', _).constant('ColorThief', ColorThief);

"use strict";
function config($compileProvider) {
  $compileProvider.imgSrcSanitizationWhitelist(/^\s*(blob:|data:image)|chrome-extension:/);
}
config.$inject = ["$compileProvider"];
angular.module('PVL').config(config);

"use strict";
function EventBus($rootScope) {
  function emit(evtName, payload) {
    $rootScope.$emit(evtName, payload);
  }
  function on(evtName, cb) {
    return $rootScope.$on(evtName, cb);
  }
  return {
    emit: emit,
    on: on
  };
}
EventBus.$inject = ["$rootScope"];
angular.module('PVL').service('EventBus', EventBus);

"use strict";
function MainCtrl(PvlService, $rootScope) {
  var vm = this,
      version = chrome.runtime.getManifest().version,
      beta = true;
  vm.appVersion = version + (beta ? '_BETA' : '');
  PvlService.getNowPlaying().on('nowplaying', (function(data) {
    $rootScope.$emit('pvl:nowPlaying', data);
  }));
}
MainCtrl.$inject = ["PvlService", "$rootScope"];
angular.module('PVL').controller('MainCtrl', MainCtrl);

"use strict";
function MediaPlayerCtrl($scope, $element, $timeout, EventBus, PvlService, ColorThief) {
  var vm = this;
  var defaultArtwork = '/images/mascot.png';
  var colorThief = new ColorThief();
  var playingCache = {};
  var mediaElement = angular.element('audio', $element);
  var artworkImg = angular.element('.artwork img', $element);
  var flipEl = angular.element('.flipper');
  vm.nowPlaying = null;
  vm.artworkUrl = defaultArtwork;
  vm.isLoading = true;
  vm.isPlaying = false;
  vm.togglePlayback = togglePlayback;
  vm.station = null;
  vm.mediaElement = mediaElement[0];
  function togglePlayback() {
    if (vm.mediaElement.paused) {
      vm.mediaElement.play();
    } else {
      vm.mediaElement.pause();
    }
  }
  mediaElement.on({
    loadstart: (function() {
      return $scope.$apply((function() {
        return vm.isLoading = true;
      }));
    }),
    canplay: (function() {
      return $scope.$apply((function() {
        return vm.isLoading = false;
      }));
    }),
    play: (function() {
      return $scope.$apply((function() {
        return vm.isPlaying = true;
      }));
    }),
    pause: (function() {
      return $scope.$apply((function() {
        return vm.isPlaying = false;
      }));
    })
  });
  var stationListener = (function(evt, station) {
    vm.station = station;
    if (playingCache[station.shortcode]) {
      vm.nowPlaying = playingCache[station.shortcode];
    }
    if (flipEl.hasClass('flipped')) {
      flipEl.toggleClass('double-flipped');
    }
  });
  var nowPlayingListener = (function(evt, data) {
    playingCache = data;
    if (!vm.station)
      return;
    var datum = data[vm.station.shortcode],
        externalData = datum.current_song.external,
        url = defaultArtwork;
    if (externalData.hasOwnProperty('bronytunes')) {
      if (externalData.bronytunes.hasOwnProperty('image_url')) {
        url = externalData.bronytunes.image_url;
      }
    }
    vm.nowPlaying = data[vm.station.shortcode];
    vm.artworkUrl = url;
  });
  var unsubStationSelect = EventBus.on('pvl:stationSelect', stationListener);
  var unsubNowPlaying = EventBus.on('pvl:nowPlaying', nowPlayingListener);
  $scope.$on('$destroy', (function() {
    unsubStationSelect();
    unsubNowPlaying();
  }));
}
MediaPlayerCtrl.$inject = ["$scope", "$element", "$timeout", "EventBus", "PvlService", "ColorThief"];
function MediaPlayerDirective() {
  return {
    restrict: 'E',
    templateUrl: '/mediaPlayer.html',
    scope: true,
    controller: MediaPlayerCtrl,
    controllerAs: 'mediaPlayer',
    bindToController: true
  };
}
angular.module('PVL').directive('pvlMediaPlayer', MediaPlayerDirective);

"use strict";
function PvlService($http, $q, $sce, io) {
  var apiHost = "https://ponyvillelive.com";
  var apiBase = (apiHost + "/api");
  var socket,
      stationCache = {};
  function getStations(type) {
    var deferred = $q.defer();
    if (stationCache[type]) {
      deferred.resolve(stationCache[type]);
      return;
    }
    $http.get(this.apiBase + "/station/list/category/" + type, {transformResponse: (function(data) {
        var payload = JSON.parse(data),
            stations = payload.result;
        stations.forEach((function(station) {
          station.safe_img_url = '';
          station.stream_url = $sce.trustAsResourceUrl(station.stream_url);
          $http.get(("" + station.image_url), {responseType: 'blob'}).success((function(response) {
            var fileUrl = URL.createObjectURL(response);
            station.safe_img_url = $sce.trustAsResourceUrl(fileUrl);
          })).error((function(err) {
            return station.safe_img_url = '/images/pvl_128.png';
          }));
        }));
        return payload;
      })}).success((function(json) {
      deferred.resolve(json.result);
      stationCache[type] = json.result;
    })).error((function(err) {
      return deferred.reject(err);
    }));
    return deferred.promise;
  }
  function getNowPlaying() {
    if (!socket) {
      socket = io("wss://api.ponyvillelive.com", {path: '/live'});
    }
    return socket;
  }
  return {
    apiBase: apiBase,
    getStations: getStations,
    getNowPlaying: getNowPlaying
  };
}
PvlService.$inject = ["$http", "$q", "$sce", "io"];
angular.module('PVL').service('PvlService', PvlService);

"use strict";
function StationListCtrl($scope, EventBus, PvlService) {
  var vm = this;
  vm.imgUrls = {};
  vm.nowPlaying = {};
  vm.currentIndex = null;
  vm.setSelected = setSelected;
  function setSelected(index) {
    vm.currentIndex = index;
    EventBus.emit('pvl:stationSelect', vm.stations[index]);
  }
  PvlService.getStations('audio').then((function(stations) {
    return vm.stations = stations;
  }));
  var nowPlayingListener = (function(event, data) {
    vm.nowPlaying = data;
  });
  var unsubNowPlaying = EventBus.on('pvl:nowPlaying', nowPlayingListener);
  $scope.$on('$destroy', (function() {
    unsubNowPlaying();
  }));
}
StationListCtrl.$inject = ["$scope", "EventBus", "PvlService"];
function StationListDirective() {
  return {
    restrict: 'E',
    templateUrl: '/stationList.html',
    scope: true,
    controller: StationListCtrl,
    controllerAs: 'stationList',
    bindToController: true
  };
}
angular.module('PVL').directive('pvlStationList', StationListDirective);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFwcC5qcyIsIkNvbmZpZy5qcyIsIkV2ZW50QnVzLmpzIiwiTWFpbkN0cmwuanMiLCJNZWRpYVBsYXllci5qcyIsIlB2bFNlcnZpY2UuanMiLCJTdGF0aW9uTGlzdC5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtBQUNBOztBQ0RBO0FBQ0E7RUFDRTtBQUNGLENBQUM7O0FBQ0Q7O0FDSkE7QUFDQTtFQUNFO0lBQ0U7RUFDRjtFQUNBO0lBQ0U7RUFDRjtFQUNBO0lBQ0U7SUFDQTtFQUNGO0FBQ0YsQ0FBQzs7QUFDRCwrQkFBK0IsUUFBUTs7QUNidkM7QUFDQTtFQUNFO01BQ0k7TUFDQTtFQUNKO0VBQ0E7SUFDRTtFQUNGO0FBQ0YsQ0FBQzs7QUFDRCxrQ0FBa0MsUUFBUTs7QUNWMUM7QUFDQTtFQUNFO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtJQUNFO01BQ0U7SUFDRjtNQUNFO0lBQ0Y7RUFDRjtFQUNBO0lBQ0U7TUFDRTtRQUNFO01BQ0Y7SUFDRjtJQUNBO01BQ0U7UUFDRTtNQUNGO0lBQ0Y7SUFDQTtNQUNFO1FBQ0U7TUFDRjtJQUNGO0lBQ0E7TUFDRTtRQUNFO01BQ0Y7SUFDRjtFQUNGO0VBQ0E7SUFDRTtJQUNBO01BQ0U7SUFDRjtJQUNBO01BQ0U7SUFDRjtFQUNGO0VBQ0E7SUFDRTtJQUNBO01BQ0U7SUFDRjtRQUNJO1FBQ0E7SUFDSjtNQUNFO1FBQ0U7TUFDRjtJQUNGO0lBQ0E7SUFDQTtFQUNGO0VBQ0E7RUFDQTtFQUNBO0lBQ0U7SUFDQTtFQUNGO0FBQ0YsQ0FBQzs7QUFDRDtFQUNFO0lBQ0U7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0VBQ0Y7QUFDRjtBQUNBLGlDQUFpQyxjQUFjOztBQ3RGL0M7QUFDQTtFQUNFO0VBQ0E7RUFDQTtNQUNJO0VBQ0o7SUFDRTtJQUNBO01BQ0U7TUFDQTtJQUNGO0lBQ0E7UUFDSTtZQUNJO1FBQ0o7VUFDRTtVQUNBO1VBQ0E7WUFDRTtZQUNBO1VBQ0Y7WUFDRTtVQUNGO1FBQ0Y7UUFDQTtNQUNGO01BQ0E7TUFDQTtJQUNGO01BQ0U7SUFDRjtJQUNBO0VBQ0Y7RUFDQTtJQUNFO01BQ0U7SUFDRjtJQUNBO0VBQ0Y7RUFDQTtJQUNFO0lBQ0E7SUFDQTtFQUNGO0FBQ0YsQ0FBQzs7QUFDRCwrQkFBK0IsVUFBVTs7QUM5Q3pDO0FBQ0E7RUFDRTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7SUFDRTtJQUNBO0VBQ0Y7RUFDQTtJQUNFO0VBQ0Y7RUFDQTtJQUNFO0VBQ0Y7RUFDQTtFQUNBO0lBQ0U7RUFDRjtBQUNGLENBQUM7O0FBQ0Q7RUFDRTtJQUNFO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtFQUNGO0FBQ0Y7QUFDQSxpQ0FBaUMsY0FBYyIsImZpbGUiOiJhcHAuanMiLCJzb3VyY2VzQ29udGVudCI6WyJhbmd1bGFyXG4gIC5tb2R1bGUoJ1BWTCcsIFsnbmdBbmltYXRlJ10pXG4gIC5jb25zdGFudCgnaW8nLCBpbylcbiAgLmNvbnN0YW50KCdqUXVlcnknLCAkKVxuICAuY29uc3RhbnQoJ21vbWVudCcsIG1vbWVudClcbiAgLmNvbnN0YW50KCdfJywgXylcbiAgLmNvbnN0YW50KCdDb2xvclRoaWVmJywgQ29sb3JUaGllZik7IiwiLyoqIG5nSW5qZWN0ICoqL1xuZnVuY3Rpb24gY29uZmlnKCRjb21waWxlUHJvdmlkZXIpIHtcbiAgJGNvbXBpbGVQcm92aWRlclxuICAgIC5pbWdTcmNTYW5pdGl6YXRpb25XaGl0ZWxpc3QoL15cXHMqKGJsb2I6fGRhdGE6aW1hZ2UpfGNocm9tZS1leHRlbnNpb246Lyk7XG59XG5cbmFuZ3VsYXJcbiAgLm1vZHVsZSgnUFZMJylcbiAgLmNvbmZpZyhjb25maWcpOyIsImZ1bmN0aW9uIEV2ZW50QnVzKCRyb290U2NvcGUpIHtcbiAgZnVuY3Rpb24gZW1pdChldnROYW1lLCBwYXlsb2FkKSB7XG4gICAgJHJvb3RTY29wZS4kZW1pdChldnROYW1lLCBwYXlsb2FkKTtcbiAgfVxuXG4gIGZ1bmN0aW9uIG9uKGV2dE5hbWUsIGNiKSB7XG4gICAgcmV0dXJuICRyb290U2NvcGUuJG9uKGV2dE5hbWUsIGNiKTtcbiAgfVxuXG4gIHJldHVybiB7ZW1pdCwgb259O1xufVxuXG5hbmd1bGFyXG4gIC5tb2R1bGUoJ1BWTCcpXG4gIC5zZXJ2aWNlKCdFdmVudEJ1cycsIEV2ZW50QnVzKTsiLCIvKiogbmdJbmplY3QgKiovXG5mdW5jdGlvbiBNYWluQ3RybChQdmxTZXJ2aWNlLCAkcm9vdFNjb3BlKSB7XG4gIHZhciB2bSA9IHRoaXMsXG4gICAgICB2ZXJzaW9uID0gY2hyb21lLnJ1bnRpbWUuZ2V0TWFuaWZlc3QoKS52ZXJzaW9uLFxuICAgICAgYmV0YSA9IHRydWU7IC8vIFRPRE86IEZpZ3VyZSBvdXQgYSBiZXR0ZXIgc2NoZW1lIGZvciB0aGlzP1xuXG4gIHZtLmFwcFZlcnNpb24gPSB2ZXJzaW9uICsgKGJldGE/ICdfQkVUQScgOiAnJyk7XG5cbiAgUHZsU2VydmljZVxuICBcdC5nZXROb3dQbGF5aW5nKClcbiAgXHQub24oJ25vd3BsYXlpbmcnLCBkYXRhID0+IHtcbiAgXHRcdCRyb290U2NvcGUuJGVtaXQoJ3B2bDpub3dQbGF5aW5nJywgZGF0YSk7XG4gIFx0fSk7XG59XG5cbmFuZ3VsYXJcbiAgLm1vZHVsZSgnUFZMJylcbiAgLmNvbnRyb2xsZXIoJ01haW5DdHJsJywgTWFpbkN0cmwpOyIsIi8qKiBuZ0luamVjdCAqKi9cbmZ1bmN0aW9uIE1lZGlhUGxheWVyQ3RybCgkc2NvcGUsICRlbGVtZW50LCAkdGltZW91dCwgRXZlbnRCdXMsIFB2bFNlcnZpY2UsIENvbG9yVGhpZWYpIHtcbiAgXG4gIC8qKlxuICAgKiBUbyBtYWtlIHN1cmUgd2UgaGF2ZSBhY2Nlc3MgdG8gdGhlIHZpZXdtb2RlbCBpbiBhbGwgY2xvc3VyZXNcbiAgICogd2UgZGVjbGFyZSBpdCBhcyBhIGxvY2FsLCBpbW11dGFibGUgdmFyaWFibGUuXG4gICAqL1xuICBsZXQgdm0gPSB0aGlzO1xuICBcbiAgLyoqXG4gICAqIFRoZXNlIHZhcmlhYmxlcyBhcmUgYWxsIGltbXV0YWJsZSB2YWx1ZXMgdXNlZCB0aHJvdWdob3V0XG4gICAqIHRoZSBjb2RlLlxuICAgKi9cbiAgbGV0IGRlZmF1bHRBcnR3b3JrID0gJy9pbWFnZXMvbWFzY290LnBuZyc7XG4gIGxldCBjb2xvclRoaWVmID0gbmV3IENvbG9yVGhpZWYoKTtcbiAgdmFyIHBsYXlpbmdDYWNoZSA9IHt9O1xuXG5cbiAgLyoqXG4gICAqIFRoZXNlIGFyZSBqUXVlcnkgZWxlbWVudHMgd2Ugd2FudCB0byB1c2VcbiAgICovXG4gIGxldCBtZWRpYUVsZW1lbnQgPSBhbmd1bGFyLmVsZW1lbnQoJ2F1ZGlvJywgJGVsZW1lbnQpO1xuICBsZXQgYXJ0d29ya0ltZyA9IGFuZ3VsYXIuZWxlbWVudCgnLmFydHdvcmsgaW1nJywgJGVsZW1lbnQpO1xuICBsZXQgZmxpcEVsID0gYW5ndWxhci5lbGVtZW50KCcuZmxpcHBlcicpO1xuXG4gIC8vIFRoZSBkYXRhIGZvciB0aGUgY3VycmVudGx5IHBsYXlpbmcgdHJhY2tcbiAgdm0ubm93UGxheWluZyA9IG51bGw7XG4gIC8vIFVSTCB0byB0aGUgY3VycmVudCBzb25nJ3MgY292ZXIgYXJ0XG4gIHZtLmFydHdvcmtVcmwgPSBkZWZhdWx0QXJ0d29yaztcbiAgLy8gV2hldGhlciB0aGUgYXVkaW8gZWxlbWVudHMgbG9hZGluZyBpbmRpY2F0b3Igc2hvdWxkIHNob3dcbiAgdm0uaXNMb2FkaW5nID0gdHJ1ZTtcbiAgLy8gV2hldGhlciB0aGUgYXVkaW8gZWxlbWVudCBpcyBpbiBwbGF5YmFja1xuICB2bS5pc1BsYXlpbmcgPSBmYWxzZTtcbiAgLy8gdmlld21vZGVsIGJpbmRpbmcgZm9yIG91ciB0b2dnbGUgZnVuY3Rpb25cbiAgdm0udG9nZ2xlUGxheWJhY2sgPSB0b2dnbGVQbGF5YmFjaztcbiAgLy8gVGhlIGN1cnJlbnRseSBzZWxlY3RlZCBzdGF0aW9uXG4gIHZtLnN0YXRpb24gPSBudWxsO1xuICAvLyBUaGUgcmF3IGF1ZGlvIERPTSBlbGVtZW50XG4gIHZtLm1lZGlhRWxlbWVudCA9IG1lZGlhRWxlbWVudFswXTtcblxuICAvKipcbiAgICogR2l2ZW4gdGhlIGN1cnJlbnQgc3RhdGUgb2YgdGhlIGF1ZGlvIGVsZW1lbnQsXG4gICAqIHRvZ2dsZSBpdC5cbiAgICovXG4gIGZ1bmN0aW9uIHRvZ2dsZVBsYXliYWNrKCkge1xuICAgIGlmKHZtLm1lZGlhRWxlbWVudC5wYXVzZWQpIHtcbiAgICAgIHZtLm1lZGlhRWxlbWVudC5wbGF5KCk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHZtLm1lZGlhRWxlbWVudC5wYXVzZSgpO1xuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBCaW5kaW5nIERPTSBldmVudHMgdG8gdG9nZ2xlIG91ciBhcHBsaWNhdGlvbiBzdGF0ZVxuICAgKi9cbiAgbWVkaWFFbGVtZW50Lm9uKHtcbiAgICBsb2Fkc3RhcnQ6ICAoKSA9PiAkc2NvcGUuJGFwcGx5KCgpID0+IHZtLmlzTG9hZGluZyA9IHRydWUpLFxuICAgIGNhbnBsYXk6ICAgICgpID0+ICRzY29wZS4kYXBwbHkoKCkgPT4gdm0uaXNMb2FkaW5nID0gZmFsc2UpLFxuICAgIHBsYXk6ICAgICAgICgpID0+ICRzY29wZS4kYXBwbHkoKCkgPT4gdm0uaXNQbGF5aW5nID0gdHJ1ZSksXG4gICAgcGF1c2U6ICAgICAgKCkgPT4gJHNjb3BlLiRhcHBseSgoKSA9PiB2bS5pc1BsYXlpbmcgPSBmYWxzZSlcbiAgfSk7XG5cbiAgLyoqXG4gICAqIExpc3RlbiB0byB0aGUgZXZlbnQgYnVzIGFuZCB1cGRhdGUgdGhlIHN0YXRpb24gdG9cbiAgICogYmUgdGhlIG9uZSB0aGUgdXNlciBzZWxlY3RlZCBlbHNld2hlcmUgaW4gdGhlIGFwcGxpY2F0aW9uLlxuICAgKiBBbHNvIHVwZGF0ZXMgdGhlIG5vd1BsYXlpbmcgdG8gbWF0Y2ggdGhlIGN1cnJlbnQgc3RhdGlvblxuICAgKiBpZiB0aGUgY2FjaGUgZXhpc3RzLlxuICAgKi9cbiAgbGV0IHN0YXRpb25MaXN0ZW5lciA9IChldnQsIHN0YXRpb24pID0+IHsgXG4gICAgdm0uc3RhdGlvbiA9IHN0YXRpb247XG5cbiAgICBpZihwbGF5aW5nQ2FjaGVbc3RhdGlvbi5zaG9ydGNvZGVdKSB7XG4gICAgICB2bS5ub3dQbGF5aW5nID0gcGxheWluZ0NhY2hlW3N0YXRpb24uc2hvcnRjb2RlXTtcbiAgICB9XG5cbiAgICBpZihmbGlwRWwuaGFzQ2xhc3MoJ2ZsaXBwZWQnKSkge1xuICAgICAgZmxpcEVsLnRvZ2dsZUNsYXNzKCdkb3VibGUtZmxpcHBlZCcpO1xuICAgIH1cbiAgfTtcblxuICAvKipcbiAgICogTGlzdGVuIHRvIHRoZSBldmVudCBidXMgYW5kIHVwZGF0ZSB0aGUgbm93UGxheWluZ1xuICAgKiBtZXRhZGF0YSBhbmQgY2FjaGUuXG4gICAqL1xuICBsZXQgbm93UGxheWluZ0xpc3RlbmVyID0gKGV2dCwgZGF0YSkgPT4ge1xuICAgIHBsYXlpbmdDYWNoZSA9IGRhdGE7XG5cbiAgICBpZighdm0uc3RhdGlvbikgcmV0dXJuO1xuXG4gICAgdmFyIGRhdHVtID0gZGF0YVt2bS5zdGF0aW9uLnNob3J0Y29kZV0sXG4gICAgICAgIGV4dGVybmFsRGF0YSA9IGRhdHVtLmN1cnJlbnRfc29uZy5leHRlcm5hbCxcbiAgICAgICAgdXJsID0gZGVmYXVsdEFydHdvcms7XG4gICAgXG4gICAgLyoqXG4gICAgICogUFZMIG9mZmVycyBleHRlcm5hbCBkYXRhIHRoYXQgbWlnaHQgcHJvdmlkZVxuICAgICAqIGNvdmVyIGFydHdvcmsgZm9yIHRoZSB0cmFjay4gSWYgdGhhdCBleGlzdHMsXG4gICAgICogcGFyc2UgaXQgYW5kIGxvYWQgaXQgaW50byB0aGUgbW9kZWwgb2JqZWN0XG4gICAgICogc3VjaCB0aGF0IHRoZSB2aWV3IGNhbiBsb2FkIGl0LlxuICAgICAqL1xuICAgIGlmKGV4dGVybmFsRGF0YS5oYXNPd25Qcm9wZXJ0eSgnYnJvbnl0dW5lcycpKSB7XG4gICAgICBpZihleHRlcm5hbERhdGEuYnJvbnl0dW5lcy5oYXNPd25Qcm9wZXJ0eSgnaW1hZ2VfdXJsJykpIHtcbiAgICAgICAgdXJsID0gZXh0ZXJuYWxEYXRhLmJyb255dHVuZXMuaW1hZ2VfdXJsO1xuICAgICAgfVxuICAgIH1cblxuICAgIHZtLm5vd1BsYXlpbmcgPSBkYXRhW3ZtLnN0YXRpb24uc2hvcnRjb2RlXTtcbiAgICB2bS5hcnR3b3JrVXJsID0gdXJsO1xuICB9O1xuXG4gIC8vIExpc3RlbiB0byBzdGF0aW9uIHNlbGVjdGlvbnMgb24gdGhlIGV2ZW50IGJ1c1xuICB2YXIgdW5zdWJTdGF0aW9uU2VsZWN0ICA9IEV2ZW50QnVzLm9uKCdwdmw6c3RhdGlvblNlbGVjdCcsIHN0YXRpb25MaXN0ZW5lcik7XG4gIC8vIExpc3RlbiBmb3Igbm93UGxheWluZyBkYXRhXG4gIHZhciB1bnN1Yk5vd1BsYXlpbmcgICAgID0gRXZlbnRCdXMub24oJ3B2bDpub3dQbGF5aW5nJywgbm93UGxheWluZ0xpc3RlbmVyKTtcbiAgXG4gIC8vIElmIG91ciBzY29wZSBpcyBldmVyIGRlc3RvcnllZCwgc3RvcCBsaXN0ZW5pbmcgdG8gdGhlIGV2ZW50IGJ1c1xuICAkc2NvcGUuJG9uKCckZGVzdHJveScsICgpID0+IHtcbiAgICB1bnN1YlN0YXRpb25TZWxlY3QoKTtcbiAgICB1bnN1Yk5vd1BsYXlpbmcoKTtcbiAgfSk7XG59XG5cbmZ1bmN0aW9uIE1lZGlhUGxheWVyRGlyZWN0aXZlKCkge1xuICByZXR1cm4ge1xuICAgIHJlc3RyaWN0OiAnRScsXG4gICAgdGVtcGxhdGVVcmw6ICcvbWVkaWFQbGF5ZXIuaHRtbCcsXG4gICAgc2NvcGU6IHRydWUsXG4gICAgY29udHJvbGxlcjogTWVkaWFQbGF5ZXJDdHJsLFxuICAgIGNvbnRyb2xsZXJBczogJ21lZGlhUGxheWVyJyxcbiAgICBiaW5kVG9Db250cm9sbGVyOiB0cnVlXG4gIH07XG59XG5cbmFuZ3VsYXJcbiAgLm1vZHVsZSgnUFZMJylcbiAgLmRpcmVjdGl2ZSgncHZsTWVkaWFQbGF5ZXInLCBNZWRpYVBsYXllckRpcmVjdGl2ZSk7IiwiLyoqIG5nSW5qZWN0ICoqL1xuZnVuY3Rpb24gUHZsU2VydmljZSgkaHR0cCwgJHEsICRzY2UsIGlvKSB7XG4gIGxldCBhcGlIb3N0ID0gXCJodHRwczovL3Bvbnl2aWxsZWxpdmUuY29tXCI7XG4gIGxldCBhcGlCYXNlID0gYCR7YXBpSG9zdH0vYXBpYDtcblxuICB2YXIgc29ja2V0LFxuICAgICAgc3RhdGlvbkNhY2hlID0ge307XG4gIFxuICBmdW5jdGlvbiBnZXRTdGF0aW9ucyh0eXBlKSB7XG4gICAgdmFyIGRlZmVycmVkID0gJHEuZGVmZXIoKTtcblxuICAgIGlmKHN0YXRpb25DYWNoZVt0eXBlXSkge1xuICAgICAgZGVmZXJyZWQucmVzb2x2ZShzdGF0aW9uQ2FjaGVbdHlwZV0pO1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgICRodHRwXG4gICAgICAuZ2V0KHRoaXMuYXBpQmFzZSArIFwiL3N0YXRpb24vbGlzdC9jYXRlZ29yeS9cIiArIHR5cGUsIHtcbiAgICAgICAgdHJhbnNmb3JtUmVzcG9uc2U6IGRhdGEgPT4ge1xuICAgICAgICAgIHZhciBwYXlsb2FkID0gSlNPTi5wYXJzZShkYXRhKSxcbiAgICAgICAgICAgICAgc3RhdGlvbnMgPSBwYXlsb2FkLnJlc3VsdDtcblxuICAgICAgICAgIHN0YXRpb25zLmZvckVhY2goc3RhdGlvbiA9PiB7XG4gICAgICAgICAgICBzdGF0aW9uLnNhZmVfaW1nX3VybCA9ICcnO1xuICAgICAgICAgICAgc3RhdGlvbi5zdHJlYW1fdXJsID0gJHNjZS50cnVzdEFzUmVzb3VyY2VVcmwoc3RhdGlvbi5zdHJlYW1fdXJsKTtcbiAgICAgICAgICAgICRodHRwXG4gICAgICAgICAgICAgIC5nZXQoYCR7c3RhdGlvbi5pbWFnZV91cmx9YCwge3Jlc3BvbnNlVHlwZTogJ2Jsb2InfSlcbiAgICAgICAgICAgICAgLnN1Y2Nlc3MocmVzcG9uc2UgPT4ge1xuICAgICAgICAgICAgICAgIHZhciBmaWxlVXJsID0gVVJMLmNyZWF0ZU9iamVjdFVSTChyZXNwb25zZSk7XG4gICAgICAgICAgICAgICAgc3RhdGlvbi5zYWZlX2ltZ191cmwgPSAkc2NlLnRydXN0QXNSZXNvdXJjZVVybChmaWxlVXJsKTtcbiAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgLmVycm9yKGVyciA9PiBzdGF0aW9uLnNhZmVfaW1nX3VybCA9ICcvaW1hZ2VzL3B2bF8xMjgucG5nJyk7XG4gICAgICAgICAgfSk7XG4gICAgICAgICAgICBcbiAgICAgICAgICByZXR1cm4gcGF5bG9hZDtcbiAgICAgICAgfVxuICAgICAgfSlcbiAgICAgIC5zdWNjZXNzKGpzb24gPT4ge1xuICAgICAgICBkZWZlcnJlZC5yZXNvbHZlKGpzb24ucmVzdWx0KTtcbiAgICAgICAgc3RhdGlvbkNhY2hlW3R5cGVdID0ganNvbi5yZXN1bHQ7XG4gICAgICB9KVxuICAgICAgLmVycm9yKGVyciA9PiBkZWZlcnJlZC5yZWplY3QoZXJyKSk7XG5cbiAgICAgIHJldHVybiBkZWZlcnJlZC5wcm9taXNlO1xuICB9XG5cbiAgZnVuY3Rpb24gZ2V0Tm93UGxheWluZygpIHtcbiAgICBpZighc29ja2V0KSB7XG4gICAgICBzb2NrZXQgPSBpbyhcIndzczovL2FwaS5wb255dmlsbGVsaXZlLmNvbVwiLCB7cGF0aDogJy9saXZlJ30pO1xuICAgIH1cbiAgICByZXR1cm4gc29ja2V0O1xuICB9XG5cbiAgcmV0dXJuIHthcGlCYXNlLCBnZXRTdGF0aW9ucywgZ2V0Tm93UGxheWluZ307XG59XG5cbmFuZ3VsYXJcbiAgICAubW9kdWxlKCdQVkwnKVxuICAgIC5zZXJ2aWNlKCdQdmxTZXJ2aWNlJywgUHZsU2VydmljZSk7IiwiLyoqIG5nSW5qZWN0ICoqL1xuZnVuY3Rpb24gU3RhdGlvbkxpc3RDdHJsKCRzY29wZSwgRXZlbnRCdXMsIFB2bFNlcnZpY2UpIHtcbiAgbGV0IHZtID0gdGhpcztcblxuICB2bS5pbWdVcmxzID0ge307XG4gIHZtLm5vd1BsYXlpbmcgPSB7fTtcbiAgdm0uY3VycmVudEluZGV4ID0gbnVsbDtcbiAgdm0uc2V0U2VsZWN0ZWQgPSBzZXRTZWxlY3RlZDtcblxuICBmdW5jdGlvbiBzZXRTZWxlY3RlZChpbmRleCkge1xuICAgIHZtLmN1cnJlbnRJbmRleCA9IGluZGV4O1xuICAgIEV2ZW50QnVzLmVtaXQoJ3B2bDpzdGF0aW9uU2VsZWN0Jywgdm0uc3RhdGlvbnNbaW5kZXhdKTtcbiAgfVxuXG4gIFB2bFNlcnZpY2UuZ2V0U3RhdGlvbnMoJ2F1ZGlvJylcbiAgICAudGhlbihzdGF0aW9ucyA9PiB2bS5zdGF0aW9ucyA9IHN0YXRpb25zKTtcblxuICBsZXQgbm93UGxheWluZ0xpc3RlbmVyID0gKGV2ZW50LCBkYXRhKSA9PiB7XG4gICAgdm0ubm93UGxheWluZyA9IGRhdGE7XG4gIH07XG5cbiAgbGV0IHVuc3ViTm93UGxheWluZyA9IEV2ZW50QnVzLm9uKCdwdmw6bm93UGxheWluZycsIG5vd1BsYXlpbmdMaXN0ZW5lcik7XG4gICRzY29wZS4kb24oJyRkZXN0cm95JywgKCkgPT4ge1xuICAgIHVuc3ViTm93UGxheWluZygpO1xuICB9KTtcbn1cblxuZnVuY3Rpb24gU3RhdGlvbkxpc3REaXJlY3RpdmUoKSB7XG4gIHJldHVybiB7XG4gICAgcmVzdHJpY3Q6ICdFJyxcbiAgICB0ZW1wbGF0ZVVybDogJy9zdGF0aW9uTGlzdC5odG1sJyxcbiAgICBzY29wZTogdHJ1ZSxcbiAgICBjb250cm9sbGVyOiBTdGF0aW9uTGlzdEN0cmwsXG4gICAgY29udHJvbGxlckFzOiAnc3RhdGlvbkxpc3QnLFxuICAgIGJpbmRUb0NvbnRyb2xsZXI6IHRydWVcbiAgfTtcbn1cblxuYW5ndWxhclxuICAubW9kdWxlKCdQVkwnKVxuICAuZGlyZWN0aXZlKCdwdmxTdGF0aW9uTGlzdCcsIFN0YXRpb25MaXN0RGlyZWN0aXZlKTsiXSwic291cmNlUm9vdCI6Ii9zb3VyY2UvIn0=